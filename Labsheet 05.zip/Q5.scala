

  import scala.io.StdIn

  object Q5 {

    def main(args: Array[String]): Unit = {
      println("Enter n :\n")
      val n = StdIn.readInt()
      println("Sum of all even numbers upto " + n + "\n")
      val result = addition(n)
      println("Result : " + result)

    }

    def addition(n: Int): Int = {
      if (n <= 0) {
        0
      }
      else if (n % 2 == 0) {
        n + addition(n - 2)
      }
      else {
        addition(n - 1)
      }

    }

  }



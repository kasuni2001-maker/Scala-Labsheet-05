import scala.io.StdIn

object Q2 {
  def main(args : Array[String]) : Unit = {
    println("Enter n: \n")
    val n = StdIn.readInt()
    println("Prime numbers less than " +n+ "\n")
    primeSeq(n)
  }

  def primeSeq(n:Int) : Unit = {
    if (n == 2) {
      println(n)
    }
    else if (n > 2) {
      primeSeq(n - 1)
      if (isPrime(n)) {
        println(n)
      }
    }
  }

    def isPrime(number:Int) : Boolean = {
      def isDivisible(divisor : Int) : Boolean = {

        if(divisor == 1) true;
        else if(number % divisor ==0) false
        else isDivisible(divisor - 1)
      }
      isDivisible(number -1)
    }

}
import scala.io.StdIn

object Q4 {

  def main(args : Array[String]) : Unit = {
    println("Enter n : \n")
    val n = StdIn.readInt()
    println("Even numbers and odd numbers from 1 to " +n)
    display(n)
  }

  def display(n:Int) : Unit = {
       if(n>0)
         {
           display(n-1)
           if(isEven(n))
             println( n+ " is even")
           else
             println( n+ " is odd")
         }
  }

  def isEven(number : Int) : Boolean ={
    if(number ==0 ) true
    else isOdd(number-1)
  }

  def isOdd(number : Int) : Boolean ={
    if(number == 0) false
    else isEven(number - 1)
  }

}
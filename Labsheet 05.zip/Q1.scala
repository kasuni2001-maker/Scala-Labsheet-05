import scala.annotation.tailrec
import scala.io.StdIn

object Q1 {
  def main(args: Array[String]): Unit = {
    println("Enter a integer: \n")
    val number = StdIn.readInt()

    if (isPrime(number))
      println(s"$number is a prime number")
    else
      println(s" $number is not a prime number")
  }

    def isPrime(n: Int): Boolean = {
      def divideBy(m: Int, divisor: Int): Boolean = {
        if (divisor <= 1) false
        else if (m % divisor == 0) true
        else divideBy(m, divisor - 1)
      }

      if (n <= 1) false
      else divideBy(n, Math.sqrt(n).toInt)
    }
}

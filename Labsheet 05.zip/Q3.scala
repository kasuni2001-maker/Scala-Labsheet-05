import scala.io.StdIn

object Q3 {

   def main(args : Array[String]) : Unit = {
     println("Enter n : \n")
     val n = StdIn.readInt()
     println("Additon of numbers from 1 to " +n+"\n")
     val result = addition(n)
     println("Result = " +result)
   }

  def addition(n:Int) : Int = {
    if(n<=0)
      {
        0
      }
    else
      {
        n+ addition(n-1)
      }

  }
}
